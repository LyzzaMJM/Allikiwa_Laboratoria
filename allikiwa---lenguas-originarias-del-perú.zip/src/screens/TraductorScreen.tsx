import React, { useState } from 'react';
import { ScreenId, TransitionType } from '../types';
import { sounds } from '../utils/audio';

interface Props {
  onNavigate: (screen: ScreenId, transition?: TransitionType) => void;
}

export const TraductorScreen: React.FC<Props> = ({ onNavigate }) => {
  const [inputText, setInputText] = useState('¿Cómo estás, hermano? Que tengas un buen día en la comunidad.');
  const [targetLang, setTargetLang] = useState<'chanka' | 'aimara'>('chanka');
  const [isAudioModalOpen, setIsAudioModalOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [speed, setSpeed] = useState<'normal' | 'slow'>('normal');
  const [copied, setCopied] = useState(false);
  const [isListening, setIsListening] = useState(false);

  const translations = {
    chanka: {
      langName: 'Quechua Chanka',
      result: 'Allillanchu wawkillay? Allin punchaw kachun ayllunchikpi.',
      phonetics: 'a-yí-llan-chu waw-kí-llay? a-yín pun-chaw ka-chun ay-llun-chik-pi',
      sabiasQue: 'En Quechua Chanka, la palabra "wawqillay" se expresa con enorme ternura entre hermanos varones o amigos entrañables. El sufijo final "-lla" añade dulzura, cariño y afecto sincero.'
    },
    aimara: {
      langName: 'Aimara',
      result: 'Kamisaraki jilata? Aski urukipan ayllusana.',
      phonetics: 'ka-mi-sa-ra-ki ji-la-ta? as-ki u-ru-ki-pan ay-llu-sa-na',
      sabiasQue: 'En Aimara, "jilata" representa una hermandad profunda de sangre o de vida comunitaria basada en la reciprocidad andina (Ayni y Minka).'
    }
  };

  const currentTrans = translations[targetLang];

  const handleListen = () => {
    sounds.playVoice(currentTrans.result, speed === 'slow');
  };

  const handleToggleVoiceInput = () => {
    sounds.playTap();
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      setIsListening(!isListening);
      if (!isListening) {
        setTimeout(() => {
          setInputText('Allillanchu wawqillay, ¿cómo estás hoy?');
          setIsListening(false);
          sounds.playSuccess();
        }, 1500);
      }
      return;
    }

    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = 'es-PE';
      recognition.onstart = () => setIsListening(true);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        setIsListening(false);
        sounds.playSuccess();
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);
      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  return (
    <div className="bg-[#fbf7ee] text-[#332219] antialiased flex flex-col min-h-screen">
      {/* ================= TOP NAV BAR ================= */}
      <header className="w-full bg-white border-b-2 border-[#e5e2da] sticky top-0 z-50">
        <div className="w-full px-4 sm:px-6 md:px-10 max-w-7xl mx-auto flex justify-between items-center h-20">
          {/* Logo Allikiwa */}
          <a
            className="flex items-center gap-3 group cursor-pointer"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('traductor', 'none');
            }}
            href="#allikiwa"
          >
            <img
              src="https://lh3.googleusercontent.com/aida/AEtjO1U0JKJCA5X60akC54J71gPC96isz8OIWR75N9_CNQDZaNJ3eWzGdmWjaboM2Tvag-2GBT82owKoFGtlM7MaOIWJFjDCyAKpHCElmsxmhryqhdl1xdeZEvenlYXg14a4H_dP9P33o9t3nDuNuY07QmHOefJZiCcutb1g4N-AcR2UK4fBlV7veM7-auzxnlwbUVr0cbOtdDksN6UG-Di5lC-mZku_O1H_PiW-1krqPPCU"
              alt="Logo Allikiwa"
              className="w-10 h-10 object-contain rounded-xl shadow-xs"
            />
            <div className="flex flex-col">
              <span className="font-chubby text-2xl font-extrabold text-[#f27a21] tracking-wide flex items-center gap-1.5 leading-tight">
                Allikiwa
                <span className="text-[10px] uppercase px-2 py-0.5 rounded-full bg-[#fff3e8] text-[#f27a21] border border-[#f27a21]/30 font-extrabold tracking-wider">
                  Perú
                </span>
              </span>
              <span className="text-xs font-bold text-[#8c7e73] -mt-0.5 hidden sm:block">
                Aprende, practica y conecta con nuestras lenguas
              </span>
            </div>
          </a>

          {/* Navigation Links: STRICTLY 'Traductor' and 'Aprender' */}
          <nav className="flex items-center space-x-2 sm:space-x-4">
            <a
              className="px-4 sm:px-5 py-2 sm:py-2.5 rounded-2xl font-chubby text-sm sm:text-base font-bold flex items-center gap-2 bg-[#ebedfa] text-[#2a3691] border-2 border-[#2a3691]/30 shadow-sm transition-all cursor-pointer"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('traductor', 'none');
              }}
              href="#traductor"
            >
              <span className="material-symbols-outlined text-[20px] sm:text-[22px]">g_translate</span>
              <span>Traductor</span>
            </a>
            <a
              className="px-4 sm:px-5 py-2 sm:py-2.5 rounded-2xl font-chubby text-sm sm:text-base font-bold text-[#7a6f66] hover:bg-[#f0ece1] hover:text-[#2a3691] transition-all flex items-center gap-2 cursor-pointer"
              onClick={(e) => {
                e.preventDefault();
                sounds.playTap();
                onNavigate('mapa_quechua', 'push');
              }}
              href="#aprender"
            >
              <span className="material-symbols-outlined text-[20px] sm:text-[22px]">school</span>
              <span>Aprender</span>
            </a>
          </nav>

          {/* Trailing Phonetic Badge & Profile */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            <button
              className="hidden sm:flex border-2 border-[#d6d1c4] rounded-2xl px-3.5 py-2 bg-white hover:bg-[#fbf7ee] text-[#2a3691] font-chubby text-sm font-bold items-center gap-2 shadow-duo-neutral btn-3d"
              title="Lenguas activas"
              type="button"
              onClick={() => onNavigate('perfil_registro', 'push')}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-[#3ca21d] animate-pulse"></span>
              <span>ES / AY / QUE</span>
            </button>
            <button
              aria-label="Perfil y racha"
              className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-[#fdf2e9] border-2 border-[#f3d3bc] text-[#f27a21] flex items-center justify-center hover:bg-[#fff3e8] shadow-duo-neutral btn-3d cursor-pointer"
              type="button"
              onClick={() => {
                sounds.playTap();
                onNavigate('perfil_dinamico', 'push');
              }}
            >
              <span className="material-symbols-outlined text-[26px] sm:text-[28px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                face_6
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* ================= MAIN CONTENT ================= */}
      <main className="flex-grow max-w-7xl mx-auto w-full px-4 sm:px-6 md:px-10 py-7">
        {/* Welcome Section */}
        <section className="mb-7">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2">
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#e9f7e5] border-2 border-[#3ca21d]/30 text-[#2d7d15] mb-3">
                <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                  sparkles
                </span>
                <span className="font-chubby text-sm font-bold tracking-wide">¡Aprende y traduce jugando!</span>
              </div>
              <h1 className="font-chubby text-3xl sm:text-4xl font-extrabold text-[#2a3691] tracking-tight">
                Habla y siente nuestras lenguas originarias
              </h1>
              <p className="text-base sm:text-lg font-bold text-[#73685f] mt-1 max-w-2xl">
                Escribe o habla con tu voz para traducir de forma sencilla y alegre entre español,{' '}
                <span className="text-[#f27a21] font-extrabold">Quechua Chanka</span> y{' '}
                <span className="text-[#3ca21d] font-extrabold">Aimara</span>.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2.5 self-start md:self-auto">
              <span className="px-4 py-2 rounded-2xl bg-white border-2 border-[#e5e2da] text-[#f27a21] font-chubby text-sm font-bold flex items-center gap-2 shadow-sm">
                <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                  mic
                </span>
                Audio y Voz activa
              </span>
              <span className="px-4 py-2 rounded-2xl bg-white border-2 border-[#e5e2da] text-[#3ca21d] font-chubby text-sm font-bold flex items-center gap-2 shadow-sm">
                <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                  verified
                </span>
                100% Amigable
              </span>
            </div>
          </div>
        </section>

        {/* ================= TRANSLATOR DUAL CONTAINER ================= */}
        <section
          className={`bg-white rounded-[32px] border-2 border-[#d6d1c4] shadow-duo-card overflow-hidden mb-10 ${
            isFullscreen ? 'fixed inset-0 z-50 p-4 sm:p-8 overflow-y-auto bg-[#fbf7ee] rounded-none border-none' : ''
          }`}
          id="translator-main-container"
        >
          {/* Header Bar */}
          <div className="p-4 sm:p-6 bg-[#fdfbf7] border-b-2 border-[#e5e2da]">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#e5e2da]">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-[#3ca21d] animate-pulse"></span>
                <span className="font-chubby text-xs sm:text-sm font-extrabold text-[#2a3691] uppercase tracking-wider">
                  Estación de Traducción e Interculturalidad
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  id="btn-toggle-fullscreen"
                  onClick={() => setIsFullscreen(!isFullscreen)}
                  className="btn-3d px-3.5 py-1.5 rounded-xl bg-[#ebedfa] hover:bg-[#2a3691] text-[#2a3691] hover:text-white border-2 border-[#2a3691]/30 font-chubby text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all shadow-sm"
                  title="Modo Expandido / Pantalla Completa"
                >
                  <span className="material-symbols-outlined text-[18px]">
                    {isFullscreen ? 'fullscreen_exit' : 'fullscreen'}
                  </span>
                  <span>{isFullscreen ? 'Salir de Completa' : 'Pantalla Completa'}</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-[1fr,auto,1fr] items-center gap-4">
              {/* Input Language Box */}
              <div className="flex items-center justify-between bg-white px-5 py-3.5 rounded-2xl border-2 border-[#e5e2da] shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#ebedfa] text-[#2a3691] flex items-center justify-center">
                    <span className="material-symbols-outlined text-[22px]">flag</span>
                  </div>
                  <div>
                    <span className="text-xs font-extrabold text-[#9c8e82] uppercase tracking-wider block">
                      Idioma de entrada
                    </span>
                    <span className="font-chubby text-xl font-bold text-[#2a3691]">Español</span>
                  </div>
                </div>
                <span className="material-symbols-outlined text-[#3ca21d] text-[26px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                  check_circle
                </span>
              </div>

              {/* Swap Button */}
              <div className="flex justify-center -my-2 md:my-0">
                <button
                  className="w-12 h-12 rounded-2xl bg-white text-[#2a3691] border-2 border-[#d6d1c4] hover:border-[#2a3691] hover:bg-[#ebedfa] flex items-center justify-center shadow-duo-neutral btn-3d"
                  title="Cambiar orden de idiomas"
                  type="button"
                  onClick={() => {
                    sounds.playTap();
                    setTargetLang(targetLang === 'chanka' ? 'aimara' : 'chanka');
                  }}
                >
                  <span className="material-symbols-outlined text-[26px]">swap_horiz</span>
                </button>
              </div>

              {/* Target Language Selector */}
              <div className="flex items-center justify-between bg-[#fff3e8]/50 px-5 py-3 rounded-2xl border-2 border-[#f27a21]/40 shadow-sm">
                <div className="flex items-center gap-3 flex-grow">
                  <div className="w-10 h-10 rounded-xl bg-[#f27a21] text-white flex items-center justify-center shadow-sm">
                    <span className="material-symbols-outlined text-[22px]">record_voice_over</span>
                  </div>
                  <div className="w-full">
                    <span className="text-xs font-extrabold text-[#c95c10] uppercase tracking-wider block">Traducir a</span>
                    <select
                      className="bg-transparent font-chubby text-lg font-bold text-[#2a3691] border-none p-0 focus:ring-0 cursor-pointer w-full leading-tight"
                      id="friendly-target-lang"
                      value={targetLang}
                      onChange={(e) => {
                        sounds.playTap();
                        setTargetLang(e.target.value as 'chanka' | 'aimara');
                      }}
                    >
                      <option value="chanka">Quechua Chanka (Ayacucho)</option>
                      <option value="aimara">Aimara (Puno y Altiplano)</option>
                    </select>
                  </div>
                </div>
                <span className="material-symbols-outlined text-[#f27a21] text-[24px] pointer-events-none">expand_more</span>
              </div>
            </div>
          </div>

          {/* Interactive Translation Workspace */}
          <div className="grid grid-cols-1 lg:grid-cols-2 divide-y-2 lg:divide-y-0 lg:divide-x-2 divide-[#e5e2da]">
            {/* Source Panel */}
            <div className="p-6 sm:p-8 flex flex-col justify-between min-h-[350px] bg-white">
              <div>
                <div className="flex justify-between items-center mb-3">
                  <span className="font-chubby text-xs sm:text-sm font-bold text-[#94867a] uppercase tracking-wider flex items-center gap-2">
                    <span className="material-symbols-outlined text-[18px]">edit_note</span> Escribe o dicta aquí
                  </span>
                  <button
                    className="text-[#94867a] hover:text-[#b43f1d] transition-colors flex items-center gap-1 font-bold text-sm px-2.5 py-1 rounded-xl hover:bg-[#b43f1d]/10 cursor-pointer"
                    title="Borrar todo"
                    type="button"
                    onClick={() => {
                      sounds.playTap();
                      setInputText('');
                    }}
                  >
                    <span className="material-symbols-outlined text-[18px]">delete</span>
                    Borrar
                  </button>
                </div>
                <textarea
                  className="w-full bg-transparent border-0 resize-none font-bold text-xl sm:text-2xl text-[#2b201a] focus:ring-0 p-0 h-40 leading-relaxed placeholder-[#c2b9af] focus:outline-none"
                  id="input-friendly-text"
                  placeholder="Escribe lo que quieras decir o presiona el botón de micrófono..."
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                />
              </div>

              {/* Action Toolbar */}
              <div className="pt-5 border-t-2 border-[#e5e2da] flex flex-wrap items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    className={`btn-3d px-4 sm:px-5 py-2.5 sm:py-3 rounded-2xl ${
                      isListening ? 'bg-[#b43f1d] border-[#8a2b0e] animate-pulse' : 'bg-[#2a3691] border-[#1a2260]'
                    } text-white border-b-4 shadow-duo-blue flex items-center gap-2.5 font-chubby cursor-pointer`}
                    title="Presiona para hablar"
                    type="button"
                    onClick={handleToggleVoiceInput}
                  >
                    <span className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
                      <span className="material-symbols-outlined text-[20px]">{isListening ? 'graphic_eq' : 'mic'}</span>
                    </span>
                    <div className="text-left leading-tight">
                      <span className="font-bold text-sm sm:text-base block">{isListening ? 'Escuchando...' : 'Toca para Hablar'}</span>
                      <span className="text-xs font-medium text-white/80">Dictado por voz</span>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      sounds.playTap();
                      setIsAudioModalOpen(true);
                    }}
                    className="btn-3d px-4 sm:px-5 py-2.5 sm:py-3 rounded-2xl bg-[#fdf2e9] hover:bg-[#fff3e8] text-[#f27a21] border-2 border-[#f27a21]/40 border-b-4 border-b-[#f27a21] shadow-duo-orange flex items-center gap-2.5 font-chubby transition-all cursor-pointer"
                    title="Subir archivo de audio (MP3, WAV, Nota de voz)"
                    type="button"
                  >
                    <span className="w-8 h-8 rounded-xl bg-[#f27a21] text-white flex items-center justify-center">
                      <span className="material-symbols-outlined text-[20px]">upload_file</span>
                    </span>
                    <div className="text-left leading-tight">
                      <span className="font-bold text-sm sm:text-base block text-[#f27a21]">Subir audio</span>
                      <span className="text-xs font-semibold text-[#8a7d72]">MP3 / WAV / Voz</span>
                    </div>
                  </button>
                </div>

                <button
                  className="btn-3d px-7 sm:px-8 py-3 rounded-2xl bg-[#f27a21] text-white border-b-4 border-[#c95c10] shadow-duo-orange flex items-center gap-2 font-chubby text-base sm:text-lg font-bold cursor-pointer"
                  type="button"
                  onClick={() => {
                    sounds.playSuccess();
                  }}
                >
                  <span className="material-symbols-outlined text-[24px]">translate</span>
                  <span>Traducir</span>
                </button>
              </div>
            </div>

            {/* Target Panel */}
            <div className="p-6 sm:p-8 flex flex-col justify-between min-h-[350px] bg-[#fdfcf9]">
              <div>
                <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                  <span className="font-chubby text-xs sm:text-sm font-bold px-3.5 py-1.5 rounded-full bg-[#e9f7e5] text-[#2d7d15] border-2 border-[#3ca21d]/30 flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                      check_circle
                    </span>
                    Traducción en {currentTrans.langName}
                  </span>
                  <span className="font-chubby text-xs font-bold text-[#f27a21] bg-[#fff3e8] px-3 py-1 rounded-full border border-[#f27a21]/30">
                    ✨ Fonética guiada
                  </span>
                </div>

                <div className="font-chubby text-2xl sm:text-3xl font-extrabold text-[#2a3691] leading-snug select-text mb-4">
                  &ldquo;{currentTrans.result}&rdquo;
                </div>

                {/* Phonetics Card */}
                <div className="bg-white p-4 rounded-2xl border-2 border-[#d6d1c4] shadow-sm flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#f27a21] text-white flex items-center justify-center shrink-0 mt-0.5">
                    <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                      volume_up
                    </span>
                  </div>
                  <div>
                    <span className="font-chubby text-xs font-extrabold text-[#f27a21] uppercase tracking-wider block">
                      ¿Cómo se pronuncia?
                    </span>
                    <p className="font-chubby text-base sm:text-lg font-bold text-[#3d3129] mt-0.5 tracking-wide">
                      &ldquo;{currentTrans.phonetics}&rdquo;
                    </p>
                  </div>
                </div>
              </div>

              {/* Playback Toolbar */}
              <div className="pt-5 border-t-2 border-[#e5e2da] flex flex-wrap items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    className="btn-3d px-6 py-3 rounded-2xl bg-[#3ca21d] text-white border-b-4 border-[#2d7d15] shadow-duo-green flex items-center gap-2.5 font-chubby text-base sm:text-lg font-bold cursor-pointer"
                    title="Escuchar pronunciación"
                    type="button"
                    onClick={handleListen}
                  >
                    <span className="material-symbols-outlined text-[24px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                      volume_up
                    </span>
                    <span>Escuchar pronunciación</span>
                  </button>

                  <div className="flex items-center bg-white p-1 rounded-2xl border-2 border-[#d6d1c4] shadow-sm">
                    <button
                      className={`px-3.5 py-1.5 rounded-xl font-chubby text-xs sm:text-sm font-bold flex items-center gap-1 transition-all ${
                        speed === 'normal' ? 'bg-[#2a3691] text-white shadow-sm' : 'text-[#7a6f66] hover:text-[#f27a21]'
                      }`}
                      title="Velocidad normal"
                      onClick={() => setSpeed('normal')}
                    >
                      <span>🔊 Normal</span>
                    </button>
                    <button
                      className={`px-3.5 py-1.5 rounded-xl font-chubby text-xs sm:text-sm font-bold flex items-center gap-1 transition-all ${
                        speed === 'slow' ? 'bg-[#f27a21] text-white shadow-sm' : 'text-[#7a6f66] hover:text-[#f27a21]'
                      }`}
                      title="Escuchar más despacio"
                      onClick={() => setSpeed('slow')}
                    >
                      <span>🐢 Lento</span>
                    </button>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    className="w-12 h-12 rounded-2xl border-2 border-[#e5e2da] bg-white text-[#70645a] hover:text-[#2a3691] hover:border-[#2a3691] flex items-center justify-center shadow-duo-neutral btn-3d cursor-pointer"
                    title="Copiar texto"
                    type="button"
                    onClick={() => {
                      navigator.clipboard?.writeText(currentTrans.result);
                      sounds.playSuccess();
                      setCopied(true);
                      setTimeout(() => setCopied(false), 2000);
                    }}
                  >
                    <span className="material-symbols-outlined text-[22px]">{copied ? 'check' : 'content_copy'}</span>
                  </button>
                  <button
                    className="w-12 h-12 rounded-2xl border-2 border-[#e5e2da] bg-white text-[#70645a] hover:text-[#f27a21] hover:border-[#f27a21] flex items-center justify-center shadow-duo-neutral btn-3d cursor-pointer"
                    title="Guardar en favoritos"
                    type="button"
                    onClick={() => {
                      sounds.playSuccess();
                    }}
                  >
                    <span className="material-symbols-outlined text-[22px]">bookmark</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ================= CULTURAL CONTEXT & MASCOT ================= */}
        <section className="bg-white rounded-[32px] border-2 border-[#d6d1c4] p-6 sm:p-9 shadow-duo-card mb-12 relative overflow-hidden">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b-2 border-[#e5e2da] mb-8">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-[#fff3e8] border-2 border-[#f27a21]/30 flex items-center justify-center text-[#f27a21] shadow-sm">
                <span className="material-symbols-outlined text-[26px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                  volunteer_activism
                </span>
              </div>
              <div>
                <h2 className="font-chubby text-2xl sm:text-3xl font-extrabold text-[#2a3691]">El corazón de nuestras palabras</h2>
                <p className="text-sm sm:text-base font-bold text-[#7a6f66]">Aprende el significado bonito y profundo de lo que acabas de traducir.</p>
              </div>
            </div>
            <span className="px-4 py-1.5 rounded-full bg-[#e9f7e5] border border-[#3ca21d]/30 text-[#2d7d15] font-chubby text-sm font-bold self-start md:self-auto flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[18px]">family_restroom</span>
              Consejo cultural para toda la familia
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Explanation Cards */}
            <div className="lg:col-span-7 space-y-5 order-2 lg:order-1">
              <div className="p-6 rounded-3xl bg-[#fffcf5] border-2 border-[#e5e2da] shadow-sm">
                <div className="flex items-center gap-2.5 text-[#f27a21] font-chubby text-xl font-bold mb-3">
                  <span className="material-symbols-outlined text-[26px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                    lightbulb
                  </span>
                  <h3>¿Sabías qué?</h3>
                </div>
                <p className="font-medium text-base sm:text-lg text-[#3b2d24] leading-relaxed mb-3">
                  {currentTrans.sabiasQue}
                </p>
                <p className="font-medium text-sm sm:text-base text-[#695d52] leading-relaxed">
                  Y al decir <strong className="text-[#2a3691] font-bold">&ldquo;ayllunchik&rdquo;</strong>, celebramos a nuestra gran familia y comunidad: <em>&ldquo;lo nuestro, de todos nosotros juntos&rdquo;</em>. En los Andes practicamos el <strong className="text-[#3ca21d] font-bold">Ayni</strong>: hoy por ti, mañana por mí.
                </p>
              </div>

              {/* Aimara Greeting Card */}
              <div className="p-5 rounded-3xl bg-white border-2 border-[#d6d1c4] shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-extrabold text-[#f27a21] uppercase tracking-wider block mb-1">
                    ¿Cómo se saluda en Aimara?
                  </span>
                  <p className="font-chubby text-xl sm:text-2xl font-bold text-[#2a3691]">&ldquo;Kamisaraki jilata?&rdquo;</p>
                  <p className="text-xs sm:text-sm font-semibold text-[#8a7d72] mt-0.5">
                    En Aimara, &ldquo;jilata&rdquo; es tu hermano de sangre o de vida.
                  </p>
                </div>
                <button
                  className="btn-3d px-5 py-2.5 rounded-2xl bg-[#f27a21] text-white border-b-4 border-[#c95c10] shadow-duo-orange font-chubby text-sm font-bold flex items-center gap-2 whitespace-nowrap self-stretch sm:self-auto justify-center cursor-pointer"
                  type="button"
                  onClick={() => sounds.playVoice('Kamisaraki jilata?')}
                >
                  <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                    volume_up
                  </span>
                  <span>Escuchar en Aimara</span>
                </button>
              </div>
            </div>

            {/* Mascot Area */}
            <div className="lg:col-span-5 flex flex-col items-center justify-center order-1 lg:order-2">
              <div className="relative w-full max-w-sm flex flex-col items-center">
                {/* Speech Bubble */}
                <div className="relative bg-white border-3 border-[#3ca21d] rounded-3xl p-4 sm:p-5 shadow-duo-green mb-3 w-full text-center border-2">
                  <p className="font-chubby text-lg sm:text-xl font-bold text-[#2a3691] leading-tight">
                    &ldquo;¡Allillanchu! 👋 Estoy aquí para ayudarte a hablar Quechua y Aimara.&rdquo;
                  </p>
                  <p className="text-xs font-extrabold text-[#3ca21d] mt-1">— Tu amigo Allikito 🦙✨</p>
                  <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[12px] border-t-[#3ca21d]"></div>
                </div>

                {/* Mascot Halo */}
                <div
                  className="relative group cursor-pointer"
                  onClick={() => {
                    sounds.playSuccess();
                  }}
                >
                  <div className="w-64 h-64 sm:w-72 sm:h-72 rounded-full bg-gradient-to-b from-[#e7f8e3] to-[#d6f2ce] border-4 border-white shadow-xl flex items-center justify-center overflow-hidden p-2 transition-transform duration-300 hover:scale-105">
                    <img
                      alt="Allikito la alpaca andina, mascota oficial de Allikiwa"
                      className="w-full h-full object-contain filter drop-shadow-md select-none transform hover:rotate-2 transition-transform duration-200"
                      src="https://lh3.googleusercontent.com/aida-public/AB6AXuABmn1pRH55CVLLb0rSmspX5w6AadGlJZHqstfSOiMupJJAWMmtXuicHY3ETZobiVWlWhUvYHFerrjq0t6JZjgqTb8qrdYKIdLxFpmXp8X33zGl4NuNN9xmpAvx1T1Hi-yZ753c6JD4ubwiBk1bJSsOZyHUGZo00PdS1EA9TVJtOlhP0kRgoy0LJ9TUsMjgMPs2OB45igctiG2-jKucXfNG92ndp0lLOXx5NbfFXYTkLA8f-xpJ1_A2"
                    />
                  </div>
                  <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-4 py-1.5 rounded-full bg-[#3ca21d] text-white font-chubby text-xs sm:text-sm font-bold shadow-md flex items-center gap-1.5 border-2 border-white whitespace-nowrap">
                    <span className="material-symbols-outlined text-[16px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                      favorite
                    </span>
                    <span>¡Compañero Allikito!</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ================= PRÓXIMAS LENGUAS ================= */}
        <section className="mb-14">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-6">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-[#ebedfa] text-[#2a3691] flex items-center justify-center">
                <span className="material-symbols-outlined text-[24px]">diversity_3</span>
              </div>
              <div>
                <h2 className="font-chubby text-2xl sm:text-3xl font-extrabold text-[#2a3691]">Próximas Lenguas en Allikiwa</h2>
                <p className="text-sm sm:text-base font-bold text-[#7a6f66]">Conversamos con sabios y comunidades para traer más tesoros lingüísticos del Perú.</p>
              </div>
            </div>
            <span className="font-chubby text-sm text-[#7a6f66] font-bold bg-white px-4 py-2 rounded-2xl border-2 border-[#e5e2da] self-start md:self-auto shadow-sm">
              ✨ Nuevas incorporaciones
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Quechua Collao */}
            <div className="bg-white rounded-[28px] border-2 border-[#d6d1c4] p-6 sm:p-7 shadow-duo-card flex flex-col justify-between hover:border-[#f27a21] transition-all">
              <div>
                <div className="flex items-center justify-between gap-3 mb-3">
                  <h3 className="font-chubby text-xl sm:text-2xl font-bold text-[#2a3691] flex items-center gap-2.5">
                    <span className="w-9 h-9 rounded-xl bg-[#fff3e8] text-[#f27a21] flex items-center justify-center">
                      <span className="material-symbols-outlined text-[20px]">landscape</span>
                    </span>
                    Quechua Collao
                  </h3>
                  <span className="px-3.5 py-1.5 rounded-full font-chubby text-xs font-extrabold bg-[#f27a21] text-white shadow-sm border border-[#c95c10]">
                    Próximamente
                  </span>
                </div>
                <p className="font-medium text-sm sm:text-base text-[#695d52] mb-5 leading-relaxed">
                  Hablado con orgullo en Cusco, Puno y las bellas alturas del sur andino. Muy pronto podrás traducirlo y escucharlo con hablantes nativos.
                </p>
              </div>
              <div className="flex items-center justify-between pt-4 border-t-2 border-[#e5e2da] font-chubby text-sm">
                <span className="text-[#7a6f66] font-bold flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[18px] text-[#f27a21]">location_on</span> Cusco y Puno
                </span>
                <span className="font-extrabold text-[#3ca21d] flex items-center gap-1">
                  <span className="material-symbols-outlined text-[18px]">trending_up</span> 65% avanzado
                </span>
              </div>
            </div>

            {/* Ese Eja */}
            <div className="bg-white rounded-[28px] border-2 border-[#d6d1c4] p-6 sm:p-7 shadow-duo-card flex flex-col justify-between hover:border-[#3ca21d] transition-all">
              <div>
                <div className="flex items-center justify-between gap-3 mb-3">
                  <h3 className="font-chubby text-xl sm:text-2xl font-bold text-[#2a3691] flex items-center gap-2.5">
                    <span className="w-9 h-9 rounded-xl bg-[#e9f7e5] text-[#3ca21d] flex items-center justify-center">
                      <span className="material-symbols-outlined text-[20px]">forest</span>
                    </span>
                    Ese Eja (Amazonía)
                  </h3>
                  <span className="px-3.5 py-1.5 rounded-full font-chubby text-xs font-extrabold bg-[#3ca21d] text-white shadow-sm border border-[#2d7d15]">
                    Próximamente
                  </span>
                </div>
                <p className="font-medium text-sm sm:text-base text-[#695d52] mb-5 leading-relaxed">
                  Lengua ancestral de nuestra Amazonía en Madre de Dios. Recopilando hermosas palabras y leyendas orales para que nunca se apaguen.
                </p>
              </div>
              <div className="flex items-center justify-between pt-4 border-t-2 border-[#e5e2da] font-chubby text-sm">
                <span className="text-[#7a6f66] font-bold flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[18px] text-[#3ca21d]">location_on</span> Madre de Dios
                </span>
                <span className="font-extrabold text-[#2a3691] flex items-center gap-1">
                  <span className="material-symbols-outlined text-[18px]">nest_eco_leaf</span> En recopilación
                </span>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* ================= AUDIO UPLOAD MODAL ================= */}
      {isAudioModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#2b201a]/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-[32px] border-4 border-[#d6d1c4] shadow-2xl max-w-lg w-full p-6 sm:p-8 relative">
            <div className="flex justify-between items-center pb-4 border-b-2 border-[#e5e2da]">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-[#fff3e8] text-[#f27a21] flex items-center justify-center border-2 border-[#f27a21]/30">
                  <span className="material-symbols-outlined text-[24px]">audio_file</span>
                </div>
                <div>
                  <h3 className="font-chubby text-xl font-bold text-[#2a3691]">Subir Audio para Traducir</h3>
                  <p className="text-xs font-semibold text-[#7a6f66]">Reconoce automáticamente Quechua, Aimara o Español</p>
                </div>
              </div>
              <button
                onClick={() => setIsAudioModalOpen(false)}
                className="w-10 h-10 rounded-xl bg-[#f0ece1] text-[#70645a] hover:bg-[#b43f1d]/10 hover:text-[#b43f1d] flex items-center justify-center font-bold text-lg transition-colors cursor-pointer"
                type="button"
              >
                <span className="material-symbols-outlined text-[22px]">close</span>
              </button>
            </div>

            <div
              className="mt-6 border-3 border-dashed border-[#f27a21]/50 hover:border-[#f27a21] bg-[#fffcf5] rounded-3xl p-6 sm:p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all hover:bg-[#fff3e8]/40 group"
              onClick={() => {
                setInputText('Allillanchu, sumaq punchaw qamkunapaq (Audio subido y procesado con éxito).');
                sounds.playSuccess();
                setIsAudioModalOpen(false);
              }}
            >
              <div className="w-16 h-16 rounded-3xl bg-[#f27a21] text-white flex items-center justify-center shadow-duo-orange mb-3 group-hover:scale-105 transition-transform">
                <span className="material-symbols-outlined text-[36px]">cloud_upload</span>
              </div>
              <span className="font-chubby text-base sm:text-lg font-bold text-[#2a3691] mb-1">
                Arrastra tu audio aquí o haz clic para explorar
              </span>
              <p className="text-xs sm:text-sm font-semibold text-[#8a7d72] mb-3">
                Formatos compatibles: MP3, WAV, M4A o nota de voz (máx. 25 MB)
              </p>
              <div className="flex flex-wrap items-center justify-center gap-2">
                <span className="px-3 py-1 rounded-full bg-white border border-[#e5e2da] text-xs font-bold text-[#2a3691]">
                  ✨ Auto-transcripción
                </span>
                <span className="px-3 py-1 rounded-full bg-white border border-[#e5e2da] text-xs font-bold text-[#3ca21d]">
                  🎧 Detección fonética
                </span>
              </div>
            </div>

            <div className="mt-6 p-4 rounded-2xl bg-[#fdfbf7] border-2 border-[#e5e2da] flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 overflow-hidden">
                <span className="material-symbols-outlined text-[#3ca21d] text-[28px]">mic</span>
                <div className="text-left">
                  <p className="font-chubby text-sm font-bold text-[#2a3691] truncate">ejemplo_saludo_chanka.mp3</p>
                  <p className="text-xs font-medium text-[#7a6f66]">Audio de demostración listo (0:14 seg)</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setInputText('Allillanchu, sumaq punchaw qamkunapaq (Transcrito con éxito desde el audio).');
                  sounds.playSuccess();
                  setIsAudioModalOpen(false);
                }}
                className="btn-3d px-4 py-2 rounded-xl bg-[#3ca21d] text-white border-b-2 border-[#2d7d15] shadow-duo-green font-chubby text-xs sm:text-sm font-bold flex items-center gap-1.5 shrink-0 cursor-pointer"
                type="button"
              >
                <span className="material-symbols-outlined text-[16px]">check</span>
                <span>Cargar audio</span>
              </button>
            </div>

            <div className="mt-6 flex justify-end gap-3">
              <button
                onClick={() => setIsAudioModalOpen(false)}
                className="px-5 py-2.5 rounded-2xl border-2 border-[#e5e2da] font-chubby text-sm font-bold text-[#70645a] hover:bg-[#f0ece1] transition-all cursor-pointer"
                type="button"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  setInputText('Rimaykullayki wawqillay, allillanchu kanki? (Audio subido y procesado)');
                  sounds.playSuccess();
                  setIsAudioModalOpen(false);
                }}
                className="btn-3d px-6 py-2.5 rounded-2xl bg-[#f27a21] text-white border-b-4 border-[#c95c10] shadow-duo-orange font-chubby text-sm font-bold flex items-center gap-2 cursor-pointer"
                type="button"
              >
                <span className="material-symbols-outlined text-[18px]">play_arrow</span>
                <span>Transcribir y Traducir</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= FOOTER ================= */}
      <footer className="w-full bg-white border-t-2 border-[#e5e2da] mt-auto">
        <div className="w-full px-6 md:px-12 py-8 max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-5">
          <div className="text-[#7a6f66] text-sm text-center md:text-left">
            <p className="font-chubby font-bold text-base text-[#2a3691] mb-0.5">Allikiwa — Plataforma de Traducción Intercultural</p>
            <p className="font-medium">© 2025 Allikiwa. Preservando y difundiendo las lenguas originarias del Perú. Quechua Chanka • Aimara.</p>
          </div>
          <nav className="flex flex-wrap justify-center items-center gap-5 font-chubby text-sm font-bold">
            <a className="text-[#7a6f66] hover:text-[#2a3691] transition-colors" href="#metodologia">
              Metodología Lingüística
            </a>
            <a className="text-[#7a6f66] hover:text-[#2a3691] transition-colors" href="#proximas">
              Próximas Lenguas
            </a>
            <a className="text-[#7a6f66] hover:text-[#2a3691] transition-colors" href="#recursos">
              Recursos Educativos
            </a>
            <a className="text-[#7a6f66] hover:text-[#2a3691] transition-colors" href="#privacidad">
              Privacidad y Términos
            </a>
          </nav>
        </div>
      </footer>
    </div>
  );
};
